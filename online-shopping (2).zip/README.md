# online-shopping

This is an online shopping project using Spring Boot,Spring web-flow, Spring Rest Services and Hibernate. 

## Requirements

For building and running the application you need:

- [JDK 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
- [Maven 3](https://maven.apache.org)

# Runnig this project

1. copy the githublink and clone this project https://github.com/Hanumanth6023/FinalProject.git
2. create databases schema in mysql - **online_shopping_db**
3. edit **username** and **password** in **applicaton.properties** file
4. Run Project One time or using eclipse IDE run as Java Application
5.Load the tables in database,insert data to product table
6. Then Again run project using boot
7. create user by signup

#Done by
1.Hanumantha Reddy
2.Poojitha Unnam.
3.Roshini Mohankumar
4.Sandhya Lokesh
